package com.example.nestedlayouts2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val button: Button = findViewById<View>(android.R.id.button1) as Button
        button.setOnClickListener{

            val i

            if (i % 3 == 0) {
                update(t1,t4,t8)
            }
        }
    }
}
